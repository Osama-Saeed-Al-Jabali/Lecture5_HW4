﻿namespace Lecture5_HW4
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnUp = new System.Windows.Forms.Button();
            this.btnBigHight = new System.Windows.Forms.Button();
            this.btnSmallHight = new System.Windows.Forms.Button();
            this.btnDown = new System.Windows.Forms.Button();
            this.btnRight = new System.Windows.Forms.Button();
            this.btnBigWeight = new System.Windows.Forms.Button();
            this.btnSmallWeight = new System.Windows.Forms.Button();
            this.btnLeft = new System.Windows.Forms.Button();
            this.btnPlayer = new System.Windows.Forms.Button();
            this.btnForm3 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnUp
            // 
            this.btnUp.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnUp.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUp.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnUp.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnUp.Location = new System.Drawing.Point(576, 207);
            this.btnUp.Name = "btnUp";
            this.btnUp.Size = new System.Drawing.Size(52, 39);
            this.btnUp.TabIndex = 0;
            this.btnUp.Text = "^";
            this.btnUp.UseVisualStyleBackColor = false;
            this.btnUp.Click += new System.EventHandler(this.btnUp_Click);
            // 
            // btnBigHight
            // 
            this.btnBigHight.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnBigHight.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBigHight.Location = new System.Drawing.Point(576, 264);
            this.btnBigHight.Name = "btnBigHight";
            this.btnBigHight.Size = new System.Drawing.Size(52, 39);
            this.btnBigHight.TabIndex = 1;
            this.btnBigHight.Text = "+";
            this.btnBigHight.UseVisualStyleBackColor = false;
            this.btnBigHight.Click += new System.EventHandler(this.btnBigHight_Click);
            // 
            // btnSmallHight
            // 
            this.btnSmallHight.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnSmallHight.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSmallHight.Location = new System.Drawing.Point(576, 349);
            this.btnSmallHight.Name = "btnSmallHight";
            this.btnSmallHight.Size = new System.Drawing.Size(52, 39);
            this.btnSmallHight.TabIndex = 2;
            this.btnSmallHight.Text = "-";
            this.btnSmallHight.UseVisualStyleBackColor = false;
            this.btnSmallHight.Click += new System.EventHandler(this.button3_Click);
            // 
            // btnDown
            // 
            this.btnDown.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDown.Location = new System.Drawing.Point(576, 408);
            this.btnDown.Name = "btnDown";
            this.btnDown.Size = new System.Drawing.Size(52, 39);
            this.btnDown.TabIndex = 3;
            this.btnDown.Text = "v";
            this.btnDown.UseVisualStyleBackColor = false;
            this.btnDown.Click += new System.EventHandler(this.btnDown_Click);
            // 
            // btnRight
            // 
            this.btnRight.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnRight.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRight.Location = new System.Drawing.Point(733, 304);
            this.btnRight.Name = "btnRight";
            this.btnRight.Size = new System.Drawing.Size(52, 39);
            this.btnRight.TabIndex = 4;
            this.btnRight.Text = ">";
            this.btnRight.UseVisualStyleBackColor = false;
            this.btnRight.Click += new System.EventHandler(this.btnRight_Click);
            // 
            // btnBigWeight
            // 
            this.btnBigWeight.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnBigWeight.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBigWeight.Location = new System.Drawing.Point(655, 304);
            this.btnBigWeight.Name = "btnBigWeight";
            this.btnBigWeight.Size = new System.Drawing.Size(52, 39);
            this.btnBigWeight.TabIndex = 5;
            this.btnBigWeight.Text = "+";
            this.btnBigWeight.UseVisualStyleBackColor = false;
            this.btnBigWeight.Click += new System.EventHandler(this.btnBigWeight_Click);
            // 
            // btnSmallWeight
            // 
            this.btnSmallWeight.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnSmallWeight.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSmallWeight.Location = new System.Drawing.Point(500, 304);
            this.btnSmallWeight.Name = "btnSmallWeight";
            this.btnSmallWeight.Size = new System.Drawing.Size(52, 39);
            this.btnSmallWeight.TabIndex = 6;
            this.btnSmallWeight.Text = "-";
            this.btnSmallWeight.UseVisualStyleBackColor = false;
            this.btnSmallWeight.Click += new System.EventHandler(this.btnSmallWeight_Click);
            // 
            // btnLeft
            // 
            this.btnLeft.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnLeft.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLeft.Location = new System.Drawing.Point(430, 304);
            this.btnLeft.Name = "btnLeft";
            this.btnLeft.Size = new System.Drawing.Size(52, 39);
            this.btnLeft.TabIndex = 7;
            this.btnLeft.Text = "<";
            this.btnLeft.UseVisualStyleBackColor = false;
            this.btnLeft.Click += new System.EventHandler(this.btnLeft_Click);
            // 
            // btnPlayer
            // 
            this.btnPlayer.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btnPlayer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPlayer.ForeColor = System.Drawing.Color.Red;
            this.btnPlayer.Location = new System.Drawing.Point(39, 34);
            this.btnPlayer.Name = "btnPlayer";
            this.btnPlayer.Size = new System.Drawing.Size(107, 46);
            this.btnPlayer.TabIndex = 8;
            this.btnPlayer.Text = "Player";
            this.btnPlayer.UseVisualStyleBackColor = false;
            // 
            // btnForm3
            // 
            this.btnForm3.BackColor = System.Drawing.Color.Silver;
            this.btnForm3.Location = new System.Drawing.Point(366, 541);
            this.btnForm3.Name = "btnForm3";
            this.btnForm3.Size = new System.Drawing.Size(163, 38);
            this.btnForm3.TabIndex = 11;
            this.btnForm3.Text = "Go To Form3   >>>";
            this.btnForm3.UseVisualStyleBackColor = false;
            this.btnForm3.Click += new System.EventHandler(this.btnForm3_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 591);
            this.Controls.Add(this.btnForm3);
            this.Controls.Add(this.btnPlayer);
            this.Controls.Add(this.btnLeft);
            this.Controls.Add(this.btnSmallWeight);
            this.Controls.Add(this.btnBigWeight);
            this.Controls.Add(this.btnRight);
            this.Controls.Add(this.btnDown);
            this.Controls.Add(this.btnSmallHight);
            this.Controls.Add(this.btnBigHight);
            this.Controls.Add(this.btnUp);
            this.MaximizeBox = false;
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnUp;
        private System.Windows.Forms.Button btnBigHight;
        private System.Windows.Forms.Button btnSmallHight;
        private System.Windows.Forms.Button btnDown;
        private System.Windows.Forms.Button btnRight;
        private System.Windows.Forms.Button btnBigWeight;
        private System.Windows.Forms.Button btnSmallWeight;
        private System.Windows.Forms.Button btnLeft;
        private System.Windows.Forms.Button btnPlayer;
        private System.Windows.Forms.Button btnForm3;
    }
}